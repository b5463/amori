from flask import Flask, render_template, request, redirect, url_for, jsonify
from flask_socketio import SocketIO, emit
import os
import base64

# ================================
# Author: Alexander J. Moravcik
# Date: 07/08/2024
# Description: This Flask application manages image uploads and allows real-time updates using Socket.IO.
# ================================

# Initialize Flask application
app = Flask(__name__)
app.config['SECRET_KEY'] = 'C9CFBDDD5AFCBB36C54CC8ACE63AC'
socketio = SocketIO(app)

# Configuration for file uploads
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create upload folder if it does not exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    """
    Renders the main index page with the current image.

    Returns:
        HTML template: The index page with the current image.
    """
    image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg')
    if not os.path.exists(image_path):
        image_path = 'static/uploads/default.jpg'
    else:
        image_path = 'static/uploads/current.jpg'
    last_modified_time = os.path.getmtime(image_path)
    return render_template('index.html', image_url=image_path, last_modified_time=last_modified_time)

@app.route('/upload', methods=['POST'])
def upload_file():
    """
    Handles file upload, saves the file, and notifies clients via Socket.IO.

    Returns:
        Redirect: Redirects to the upload page after saving the file.
    """
    file = request.files.get('file')
    if not file or file.filename == '':
        return redirect(request.url)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg'))
    socketio.emit('image_updated', {'last_modified': os.path.getmtime(os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg'))})
    return redirect(url_for('get_upload_page'))

@app.route('/upload', methods=['GET'])
def get_upload_page():
    """
    Renders the upload page with the current image.

    Returns:
        HTML template: The upload page with the current image.
    """
    image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg')
    if not os.path.exists(image_path):
        image_path = 'static/uploads/default.jpg'
    else:
        image_path = 'static/uploads/current.jpg'
    return render_template('upload.html', image_url=image_path)

@app.route('/last_modified')
def last_modified():
    """
    Returns the last modified time of the current image as JSON.

    Returns:
        JSON response: The last modified time of the current image.
    """
    image_path = os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg')
    last_modified_time = os.path.getmtime(image_path)
    return jsonify({'last_modified': last_modified_time})

@app.route('/undo', methods=['POST'])
def undo():
    """
    Handles the undo action by restoring the previous state of the image.

    Returns:
        JSON response: Success or error message.
    """
    state = request.form.get('state')
    if not state:
        return jsonify({'status': 'error', 'message': 'No state provided'}), 400
    state_data = state.split(',')[1]  # Remove the data URL prefix
    with open(os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg'), 'wb') as f:
        f.write(base64.b64decode(state_data))
    socketio.emit('image_updated', {'last_modified': os.path.getmtime(os.path.join(app.config['UPLOAD_FOLDER'], 'current.jpg'))})
    return jsonify({'status': 'success'}), 200

if __name__ == '__main__':
    # Run the Flask application with Socket.IO support
    socketio.run(app, debug=True, port=5001)