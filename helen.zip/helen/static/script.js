/**
 * Drawing Canvas Script
 * Author: Alexander J. Moravcik
 * Description: This script handles the image upload, drawing annotations on a canvas,
 * and saving the annotated image to the server.
 */

document.addEventListener('DOMContentLoaded', () => {
    // ===============================
    // Elements
    // ===============================
    const fileInput = document.getElementById('fileInput');
    const uploadButton = document.getElementById('uploadButton');
    const uploadForm = document.getElementById('uploadForm');
    const undoButton = document.getElementById('undoButton');
    const drawingCanvas = document.getElementById('drawingCanvas');
    const currentImage = document.getElementById('currentImage');
    const ctx = drawingCanvas.getContext('2d');
    const navbarHeight = document.querySelector('.header').offsetHeight;

    // ===============================
    // State Variables
    // ===============================
    let drawing = false;
    let undoStack = [];
    let resizeTimeout;

    // ===============================
    // Event Listeners
    // ===============================
    if (uploadButton) {
        uploadButton.addEventListener('click', () => fileInput.click());
    }

    if (fileInput) {
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                uploadForm.submit();
            }
        });
    }

    if (undoButton) {
        undoButton.addEventListener('click', undoLastAction);
    }

    window.addEventListener('resize', handleResize);
    currentImage.addEventListener('load', resizeCanvas);
    drawingCanvas.addEventListener('mousedown', startDrawing);
    drawingCanvas.addEventListener('mousemove', draw);
    drawingCanvas.addEventListener('mouseup', stopDrawing);
    drawingCanvas.addEventListener('mouseout', stopDrawing);
    drawingCanvas.addEventListener('touchstart', startDrawing);
    drawingCanvas.addEventListener('touchmove', draw);
    drawingCanvas.addEventListener('touchend', stopDrawing);
    drawingCanvas.addEventListener('touchcancel', stopDrawing);

    // ===============================
    // Functions
    // ===============================

    /**
     * Resizes the canvas to match the aspect ratio of the current image.
     * This function is called when the image loads or the window is resized.
     */
    function resizeCanvas() {
        const imageAspectRatio = currentImage.naturalWidth / currentImage.naturalHeight;
        const canvasAspectRatio = drawingCanvas.width / drawingCanvas.height;

        if (imageAspectRatio > canvasAspectRatio) {
            drawingCanvas.width = currentImage.clientWidth;
            drawingCanvas.height = currentImage.clientWidth / imageAspectRatio;
        } else {
            drawingCanvas.height = currentImage.clientHeight;
            drawingCanvas.width = currentImage.clientHeight * imageAspectRatio;
        }

        redrawAnnotations();
    }

    /**
     * Gets the offset coordinates for mouse/touch events relative to the canvas.
     * @param {MouseEvent | TouchEvent} e - The event object.
     * @returns {Object} - The offset coordinates {offsetX, offsetY}.
     */
    function getOffset(e) {
        const rect = drawingCanvas.getBoundingClientRect();
        const scaleX = drawingCanvas.width / rect.width;
        const scaleY = drawingCanvas.height / rect.height;
        const offsetX = e.touches ? (e.touches[0].clientX - rect.left) * scaleX : (e.clientX - rect.left) * scaleX;
        const offsetY = e.touches ? (e.touches[0].clientY - rect.top) * scaleY : (e.clientY - rect.top) * scaleY;
        return { offsetX, offsetY };
    }

    /**
     * Starts the drawing process on the canvas.
     * @param {MouseEvent | TouchEvent} e - The event object.
     */
    function startDrawing(e) {
        e.preventDefault();
        const { offsetX, offsetY } = getOffset(e);
        drawing = true;
        ctx.beginPath();
        ctx.moveTo(offsetX, offsetY);
    }

    /**
     * Draws on the canvas as the mouse or touch moves.
     * @param {MouseEvent | TouchEvent} e - The event object.
     */
    function draw(e) {
        if (!drawing) return;
        e.preventDefault();
        const { offsetX, offsetY } = getOffset(e);
        ctx.lineTo(offsetX, offsetY);
        ctx.stroke();
    }

    /**
     * Stops the drawing process and saves the current state of the canvas.
     */
    function stopDrawing() {
        if (!drawing) return;
        drawing = false;
        saveState();
        saveDrawing();
    }

    /**
     * Saves the current state of the canvas to the undo stack.
     */
    function saveState() {
        const state = drawingCanvas.toDataURL();
        undoStack.push(state);
    }

    /**
     * Redraws annotations from the undo stack.
     */
    function redrawAnnotations() {
        ctx.clearRect(0, 0, drawingCanvas.width, drawingCanvas.height);
        if (undoStack.length > 0) {
            const img = new Image();
            img.src = undoStack[undoStack.length - 1];
            img.onload = () => ctx.drawImage(img, 0, 0, drawingCanvas.width, drawingCanvas.height);
        }
    }

    /**
     * Undoes the last action by removing the last state from the undo stack.
     */
    function undoLastAction() {
        if (undoStack.length > 0) {
            undoStack.pop();
            redrawAnnotations();
            saveDrawing();
        }
    }

    /**
     * Saves the current drawing to the server.
     * Combines the original image and the drawing into one canvas and sends it as a JPEG blob.
     */
    function saveDrawing() {
        const combinedCanvas = document.createElement('canvas');
        const combinedCtx = combinedCanvas.getContext('2d');
        combinedCanvas.width = currentImage.naturalWidth;
        combinedCanvas.height = currentImage.naturalHeight;

        combinedCtx.drawImage(currentImage, 0, 0, combinedCanvas.width, combinedCanvas.height);
        const scaleX = combinedCanvas.width / drawingCanvas.width;
        const scaleY = combinedCanvas.height / drawingCanvas.height;
        combinedCtx.drawImage(drawingCanvas, 0, 0, drawingCanvas.width * scaleX, drawingCanvas.height * scaleY);

        combinedCanvas.toBlob(blob => {
            const formData = new FormData();
            formData.append('file', blob, 'current.jpg');

            fetch('/upload', {
                method: 'POST',
                body: formData,
            })
            .then(() => console.log('Drawing saved successfully'))
            .catch(error => console.error('Error:', error));
        }, 'image/jpeg', 0.95); // Added image quality parameter to speed up blob creation
    }

    /**
     * Handles the window resize event by resizing the canvas after a delay.
     */
    function handleResize() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(resizeCanvas, 100);
    }

    // Initial canvas resize
    resizeCanvas();
});