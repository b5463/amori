import qrcode
from PIL import Image
import argparse

# ================================
# Author: Alexander J. Moravcik
# Date: 07/08/2024
# Description: This script generates a QR code for a given URL and saves it to a specified file.
#              It also adds a logo to the center of the QR code.
# ================================

def generate_qr_code(url, output_file):
    """
    Generate a QR code for the given URL and save it to the specified output file.
    A logo is added to the center of the QR code.

    Parameters:
    - url (str): The URL to encode in the QR code.
    - output_file (str): The file path to save the generated QR code image.
    """
    # Create a QR Code instance
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # High error correction to accommodate the logo
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    # Create the QR Code image
    img = qr.make_image(fill_color="black", back_color="white").convert("RGBA")

    # Open the logo image
    logo = Image.open("logo.png")

    # Calculate the size of the logo and resize it
    qr_width, qr_height = img.size
    logo_size = qr_width // 4
    logo = logo.resize((logo_size, logo_size), Image.ANTIALIAS)

    # Calculate the position to place the logo
    pos = ((qr_width - logo_size) // 2, (qr_height - logo_size) // 2)

    # Paste the logo onto the QR Code image
    img.paste(logo, pos, mask=logo)

    # Save the generated QR Code image
    img.save(output_file)
    print(f"QR code generated and saved as {output_file}")

if __name__ == "__main__":
    # Set up argument parser
    parser = argparse.ArgumentParser(description='Generate a QR code from a URL with an optional logo in the center.')
    parser.add_argument('-url', type=str, required=True, help='The URL to generate a QR code for')
    parser.add_argument('-o', type=str, default='qrcode.png', help='Output file name for the QR code image (default: qrcode.png)')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Generate QR Code
    generate_qr_code(args.url, args.o)